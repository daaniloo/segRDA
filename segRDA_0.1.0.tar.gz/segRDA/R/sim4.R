#' @format Each data set is a list with the following components:
#' \describe{
#'   \item{envi}{environmental matrix}
#'   \item{comm}{community matrix}
#' }
#' @usage data(sim4)
#' @rdname sim1
"sim4"
