---
output: 
  word_document: 
    highlight: pygments
---


<!-- toc -->

junho 22, 2018

# DESCRIPTION

```
Package: segRDA
Type: Package
Title: : An R package for performing segmented redundancy analysis
Version: 0.1.0
Author: Danilo Cândido Vieira, Marco Colossi Brustolin, Gustavo Fonseca, Fabio Cop
Maintainer: Danilo Cândido Vieira <vieiradc@yahoo.com.br>
Description: The package segRDA includes two different analyses: the split-moving window (SMW) and piecewise redundancy (pwRDA) 
Depends: vegan (>= 2.4-6)
License: What license is it under?
Encoding: UTF-8
LazyData: true
RoxygenNote: 6.0.1
Suggests: 
    knitr,
    rmarkdown,
    testthat
VignetteBuilder: knitr```


# `BPlocation`: Breakpoints location

## Description


 This function is an auxiliary tool designed to identifies breakpoints along a dissimilarity profile table.


## Usage

```r
BPlocation(smw, seq.sig = 3, peaks.choice = c("max", "median"))
list(list("BPlocation"), list("smw"))(smw, ...)
list(list("BPlocation"), list("pool"))(pool, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```smw, pool```     |     an object either from class `smw` or from class `pool` , resulted from [`SMW.test`](SMW.test.html) and [`PoolSMW`](PoolSMW.html) , respectively.
```seq.sig```     |     specifies the length of a sequence of significant dissimilarity values that will be considered in defining the community breakpoints. Defaults to `seq.sig=3` ;
```peaks.choice```     |     defines if the breakpoints should be chosen as those samle positions corresponding to the maximum dissimilarity in the sequence  ( `peak.choice="max"` ) or as those sample positions corresponding to the median position of the sequence. Defaults to `peak.choice="max"` ;

## Value


 The function returns a subset of the original `DP` table containing only the samples suggested as breakpoints


## Author


 Danilo Candido Vieira


## Examples

```r 
 data(sim1)
 sim1.o<-OrdData(sim1)
 sim1.smw<-SMW.test(y.ord=sim1.o$y,w=20)
 BPlocation(sim1.smw)
 ``` 

# `Dprofile`: Plot the dissimilarity profiles

## Description


 Generates a plot with dissimilarity values vs. the location of the window midpoint. If present,
 significant dissimilarities and their peaks can be indicated.


## Usage

```r
Dprofile(smw, BPs = NA, which = c("zscore", "diss", "AverageZ"),
  pch = c(16, 16, 17), colors = c("black", "red", "blue"), bg = NULL,
  bg.colors = NULL, legend = T, ...)
list(list("Dprofile"), list("smw"))(smw, which = c("zscore", "diss"), ...)
list(list("Dprofile"), list("pool"))(pool, which = "'AverageZ'", ...)
```


## Arguments

Argument      |Description
------------- |----------------
```smw, pool```     |     It can be either an object of class `'smw'` or an object of class `'pool'`  (resulted from the functions [`SMW.test`](SMW.test.html) and [`PoolSMW`](PoolSMW.html) , respectively).
```BPs```     |     optional. A vector with the breakpoints location;
```which```     |     the column from the dissimilarity profile table to be used in the plot. For objects of class `smw` : `"diss"` for dissimilarity values and `"zscore"` for Z-scores; for objects of class `pool` : the function automatically define `which="AverageZ"`
```pch```     |     vector of length 3 specifying the symbols in plotting dissimilarity values, significant dissimilarities and breakpoints. Defaults to `pch = c(16,16,17)` ;
```colors```     |     vector of length 3 specifying the colors of the plot in the same way as the pch argument. Defaults to `colors=c("black","red","blue")`
```bg.colors```     |     vector of colors for the background according to the breakpoints. If `NULL` , the function uses the colour palette [`rainbow`](rainbow.html) from R stats;
```...```     |     Further graphical parameters
```xlab```     |     The label for the x axis
```yalb```     |     The label for the y axis

## Author


 Danilo Candido Vieira


## Examples

```r 
 data(sim1)
 sim1.o<-OrdData(sim1)
 sim1.smw<-SMW.test(y.ord=sim1.o$y,w=20)
 Dprofile(sim1.smw)
 
 sim1.pool<-PoolSMW(y.ord=sim1.o$y,windows=c(20,30,40))
 Dprofile(sim1.pool)
 ``` 

# `Dprofile2`: Plotting together the dissimilarity profiles from different windows sizes.

## Description


 Plot the dissimilarity profile using different windows sizes. This function applies only to
 objects of class `"pool"` .  Through this function,  non-transformed profiles values
 from the different windows sizes are drawn on the same plot. The function returns an invisible frequency table of breakpoints, which can be displayed in the plot.
 See [`PoolSMW`](PoolSMW.html) 


## Usage

```r
Dprofile2(pool, which = c("diss", "zscore"), title = "Pooled SMW",
  count = TRUE, legend = T, colors = NULL, xlab = NULL, ylab = NULL,
  lwd = 2, L.adj = -0.4, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```pool```     |     An  object of class `"pool"` from [`PoolSMW`](PoolSMW.html)    

*   `'Z'` : consider normalized dissimilarity (z-scores) discontinuities  that exceed a "z" critical value.  

*   `'SD'` : consider dissimilarity discontinuities that exceed mean plus one standard deviation  

*   `'SD2'` : consider dissimilarity discontinuities that exceed mean plus two standard deviation  

*   `'Tail1'` : consider dissimilarity discontinuities that exceed 95 percent confidence limits
```title```     |     An overall title for the plot
```count```     |     Logical, Should the counting table appear in the plot?
```legend```     |     Logical. Should the legend be displayed?
```colors```     |     Vector of colors for the lines. If `NULL` , the function uses the colour palette [`rainbow`](rainbow.html) from R stats
```xlab```     |     The label for the x axis
```ylab```     |     The label for the y axis
```lwd```     |     Line width
```L.adj```     |     numeric (0-1). Adjustment of the position of the legend along the axis "x"
```...```     |     Further arguments passed from BPlocation function

## Value


 Returns an invisible table with the counts of breakpoints


## Author


 Danilo Candido Vieira


## Examples

```r 
 data(sim1)
 sim1.o<-OrdData(sim1)
 sim1.pool<-PoolSMW(y.ord=sim1.o$y,windows=c(20,30,40))
 count.breaks<-Dprofile2(sim1.pool)
 count.breaks
 ``` 

# `nema`: Nematodes data from Araçá Bay, São Sebastião, Brazil.

## Description


 A total of  37 sites arranged in an irregular grid were surveyed during four sampling campaigns at the
 Araçá Bay, southeastern Brazil. A total of 141 samples were collected for analyzing changes in
 nematodes assemblages along the environmental gradient of the bay.


## Format

`nema` is a list with the following components:
 list("\n", "  ", list(list("envi"), list("a matrix with 141 sites and 9 environmental variables: chlorophyll a (mg.m-2), bathymetry (meters), percentage of total organic carbon, percentage of coarse sands (as the sum of pebbles, very coarse, coarse, and medium grains), percentage of fine sand, percentage of very fine sand, mean grain size, and sorting coefficient.")), "\n", "  ", list(list("comm"), list("matrix with 141 sites of 194 nematodes species")), "\n")

## Usage

```r
data(nema)
```


## References


   

*  Checon, H. H., D. C. Vieira, G. N. Corte, E. C. P. M. Sousa, G. Fonseca, and A. C. Z. Amaral. 2018. Defining soft bottom habitats and potential indicator species as tools for monitoring coastal systems: A case study in a subtropical bay. Ocean & Coastal Management.  

*  Corte, G. N., H. H. Checon, G. Fonseca, D. C. Vieira, F. Gallucci, M. Di Domenico, and A. C. Z. Amaral. 2017. Cross-taxon congruence in benthic communities: Searching for surrogates in marine sediments. Ecological Indicators 78:173–182. 


# `OrdData`: Data ordering

## Description


 Ordinates both community and explanatory matrices based on on the first RDA score.


## Usage

```r
OrdData(x, y, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     explanatory matrix;
```y```     |     community matrix;
```...```     |     parameters passed to vegan:: [`rda`](rda.html) ;

## Value


 a list consisting of:
  

*  envi : the ordered explanatory matrix 

*  com : the ordered community matrix 


## Author


 Danilo Candido Vieira


## Examples

```r 
 data(sim1)
 sim1.o<-OrdData(x=sim1[[1]], y=sim1[[2]])
 ``` 

# `PoolSMW`: Pooled split-moving-window analysis (SMW) with permutation tests

## Description


 Pooled split-moving-window analysis (SMW) with permutation tests


## Usage

```r
PoolSMW(y.ord, windows, n.rand = 99, z = 1.85)
```


## Arguments

Argument      |Description
------------- |----------------
```y.ord```     |     the ordered community matrix;
```windows```     |     a vector for the window sizes (all sizes have to be even);
```n.rand```     |     the number of randomizations for significance computation;
```z```     |     the critical value for significance test;

## Value


 An object of class `pool` , which is a list consisting of:
  

*   `DP` : the pooled dissimilarity profile. Dataframe giving the positions, labels, averaged z-score and the significance test for each sample. 

*   `result.pooled` : a list of of `smw` objects (returned from [`SMW.test`](SMW.test.html) ) corresponding to each window size analysed; 

*   `params` : the input arguments. 


## Author


 Danilo Candido Vieira


## References


   

*  Erdos, L., Z. Bátori, C. S. Tölgyesi, and L. Körmöczi. 2014. The moving split window (MSW) analysis in vegetation science - An overview. Applied Ecology and Environmental Research 12:787–805.  

*  Cornelius, J. M., and J. F. Reynolds. 1991. On Determining the Statistical Significance of Discontinuities with Ordered Ecological Data. Ecology 72:2057–2070. 


## Examples

```r 
 data(sim1)
 sim1.o<-OrdData(sim1)
 sim1.pool<-PoolSMW(y.ord=sim1.o$y,windows=c(20,30,40))
 ``` 

# `pwRDA`: Piecewise redundancy analysis (pwRDA)

## Description


 Perform a pwRDA using the specified breakpoints


## Usage

```r
pwRDA(x.ord, y.ord, BPs, n.rand = 99, progress = T)
```


## Arguments

Argument      |Description
------------- |----------------
```x.ord```     |     ordered explanatory matrix
```y.ord```     |     ordered community matrix
```BPs```     |     community breakpoints
```n.rand```     |     The number of randomizations for significance computation
```progress```     |     Logical. If `TRUE` displays the progress of the analysis.

## Value


 Returns an invisible list of length 4:
    

*   `summ` : summary statistics of the pwRDA analysis;  

*   `rda.0` : full model cca object,  which is described separately in [`cca.object`](cca.object.html)   

*   `rda.pw` : pw model cca object, which is described separately in [`cca.object`](cca.object.html)  


## Author


 Danilo Candido Vieira


## Examples

```r 
 data(sim1)
 sim1.o<-OrdData(sim1)
 sim1.pool<-PoolSMW(y.ord=sim1.o$y,windows=c(20,30,40))
 breaks<-BPlocation(sim1.pool)
 sim1.pw<-pwRDA(x.ord=sim1.o$x,y.ord=sim1.o$y, BPs=breaks[,1])
 ``` 

# `segRDA`: segRDA: An R package for performing piecewise redundancy analysis

## Description


 The package segRDA is straightforward through three steps: (1) data ordering, (2) breakpoints detection through split-moving-window analysis (SMW) and (3) piecewise redundancy analysis (pwRDA).


## Details


 The package includes a total of 7 functions: (1) [`OrdData`](OrdData.html) : designed to prepare the target data; (2) [`SMW.test`](SMW.test.html) and  (3) [`PoolSMW`](PoolSMW.html) : designed for performing SMW analyses; (4) [`BPlocation`](BPlocation.html) :  designed to locate the breakpoints along a dissimilarity profile; (5) [`pwRDA`](pwRDA.html) : designed to perform the pwRDA analysis; (6) [`Dprofile`](Dprofile.html) and (7) [`Dprofile2`](Dprofile2.html) designed to plot results from SMW analysis


## Author


 Danilo Candido Vieira, Gustavo Fonseca, Fabio Cop


# `sim1`: Simulated datasets

## Description


 Simulated datasets for testing segRDA package


## Format

Each data set is a list with the following components:
 list("\n", "  ", list(list("envi"), list("environmental matrix")), "\n", "  ", list(list("comm"), list("community matrix")), "\n")

## Usage

```r
data(sim1)
data(sim2)
data(sim3)
data(sim4)
```


# `SMW.test`: Split moving window analysis (SMW) with randomization tests

## Description


 This function generates a dissimilarity profile with randomizations tests using a single
 window size `w` .


## Usage

```r
SMW.test(y.ord, w, dist = "bray", n.rand = 99, rand = c("shift", "plot"),
  sig.test = c("Z", "SD", "SD2", "Tail1"), z = 1.85, progress = F)
```


## Arguments

Argument      |Description
------------- |----------------
```y.ord```     |     the ordered community matrix;
```w```     |     a numeric value for window size (has to be even);
```dist```     |     dissimilarity index used in [`vegdist`](vegdist.html) . Defaults to `'bray'` .
```n.rand```     |     the number of randomizations for significance computation;
```rand```     |     The type of randomization for significance computation (Erdös et.al, 2014):   

*   `'shift'` : restricted randomization in which data belonging to the same species are randomly shifted along the data series ("Random shift");  

*   `'plot'` : unrestricted randomization: each sample is randomly repositioned along the data series ("Random plot").
```sig.test```     |     significance test used to test whether a detected discontinuity differs significantly from those appearing in a random pattern. The following tests are considered with default to `sig.test="Z"` :   

*   `'Z'` : consider normalized dissimilarity (z-scores) discontinuities  that exceed a "z" critical value.  

*   `'SD'` : consider dissimilarity discontinuities that exceed mean plus one standard deviation;  

*   `'SD2'` : consider dissimilarity discontinuities that exceed mean plus two standard deviation;  

*   `'Tail1'` : Consider dissimilarity discontinuities that exceed 95 percent confidence limits.
```z```     |     the critical value for the significance computation Defaults to `'z=1.85'` (Erdös et.al, 2014);
```progress```     |     logical. If `TRUE` displays the progress of the analysis.

## Value


 An object of class `"smw"` , which is a list consisting of:
  

*   `DP` : the dissimilarity profile.  Dataframe giving the positions, labels, values of dissimilarity, z-scores and,  significance test for each sample; 

*   `DP.rand` : dataframe containing the randomized dissimilarity profile; 

*   `SD` standard deviation for each sample position; 

*   `D.overall` : overall expected mean dissimilarity; 

*   `SD.overall` : average standard deviation for the dissimilarities; 

*   `params` : list with input arguments. 


## Author


 Danilo Candido Vieira. Fabio Cop, Gustavo Fonseca


## References


   

*  Erdos, L., Z. Bátori, C. S. Tölgyesi, and L. Körmöczi. 2014. The moving split window (MSW) analysis in vegetation science - An overview. Applied Ecology and Environmental Research 12:787–805.  

*  Cornelius, J. M., and J. F. Reynolds. 1991. On Determining the Statistical Significance of Discontinuities with Ordered Ecological Data. Ecology 72:2057–2070. 


## Examples

```r 
 data(sim1)
 sim1.o<-OrdData(sim1)
 sim1.smw<-SMW.test(y.ord=sim1.o$y,w=20)
 ``` 

