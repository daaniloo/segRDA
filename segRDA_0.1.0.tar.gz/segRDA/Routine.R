library(base)
RdUtils("OrdData.Rd","OrdData.pdf")
Rd2HTML("SMW.test.Rd","SMW.test.html")
Rd2HTML("PoolSMW.Rd","PoolSMW.html")
Rd2HTML("BPlocation.Rd","BPlocation.html")
Rd2HTML("Dprofile.Rd","Dprofile.html")
Rd2HTML("Dprofile2.Rd","Dprofile2.html")

Rd2HTML("pwRDA.Rd","pwRDA.html")
Rd2HTML("nema.Rd","nema.html")
Rd2HTML("sim1.Rd","sim1.html")
rm(BPlocation)
?BPlocation
?SMW.test
dta(nema)
getS3method('BPlocation')
data(sim1)
require(devtools)
document()
?fbind
?Rd2pdf






image(log(sim3o[[2]])+1)

rm(BPlocation,Dprofile,Dprofile2,OrdData,SMW.test)


{data(sim1)
sim1o<-OrdData(sim1[[1]],sim1[[2]])
sim1o[[2]]<-decostand(sim1o[[2]],"hell")
sim1pool<-PoolSMW(y.ord=sim1o$y,w=c(10,20,30,40,50),n.rand=99)
sim1bp<-BPlocation(smw=sim1pool)
Dprofile(smw=sim1pool,sim1bp[,1])
sim1pw<-pwRDA(sim1o$x,sim1o$y,sim1bp[,1])
}


  {load('theo')
  simo<-OrdData(theo[[1]],theo[[2]])
  simo[[2]]<-decostand(simo[[2]],"hell")
  simpool<-PoolSMW(y.ord=simo$y,windows=c(6,12,14,18,24,30),n.rand=10)
  simbp<-BPlocation(smw=simpool)
  Dprofile(smw=simpool,simbp[,1])
  simpw<-pwRDA(simo$x,simo$y,simbp[,1])
}

simpool$result.pooled[[1]]
library(RColorBrewer)

png("Fig1.png",res=300,units="in",width = 7,height = 6)
Dprofile2(simpool,legend=F, lwd=1.5,colors=brewer.pal(n = 6, name = "Set2"),
          xlab="Sample positions",title="")
legend("topright",legend=paste("w =",c(6,12,14,18,24,30) ), bty="n",
       lty=1, col=brewer.pal(n = 6, name = "Set2"))

graphics.off()


{data(sim2)
sim2o<-OrdData(sim2[[1]],sim2[[2]])
sim2o[[2]]<-decostand(sim2o[[2]],"hell")
sim2pool<-PoolSMW(y.ord=sim2o$y,w=c(10,20,30,40,50),n.rand=99)
sim2bp<-BPlocation(smw=sim2pool)
Dprofile(smw=sim2pool,sim2bp[,1])
sim2pw<-pwRDA(sim2o$x,sim2o$y,sim2bp[,1],99)}


{data(sim3)
sim3o<-OrdData(sim3[[1]],sim3[[2]])
sim3o[[2]]<-decostand(sim3o[[2]],"hell")
sim3pool<-PoolSMW(y.ord=sim3o$y,w=c(10,20,30,40,50),n.rand=99)
sim3bp<-BPlocation(smw=sim3pool)
Dprofile(smw=sim3pool,sim3bp[,1])
sim3pw<-pwRDA(sim3o$x,sim3o$y,sim3bp[,1])
}

{data(sim4)
  sim4o<-OrdData(sim4[[1]],sim4[[2]])
  sim4o[[2]]<-decostand(sim4o[[2]],"hell")
  sim4pool<-PoolSMW(y.ord=sim4o$y,w=c(10,20,30,40,50),n.rand=99)
  sim4bp<-BPlocation(smw=sim4pool)
  Dprofile(smw=sim4pool,sim4bp[,1])
  sim4pw<-pwRDA(sim4o$x,sim4o$y,sim4bp[,1])
}

{ data(nema)
  nemao<-OrdData(nema[[1]],nema[[2]])
  nemao[[2]]<-decostand(nemao[[2]],"hell")
  nemapool<-PoolSMW(y.ord=nemao$y,w=c(20,30,40,50,60),n.rand=99)
  nemabp<-BPlocation(smw=nemapool)
  Dprofile(smw=nemapool,nemabp[,1])
  nemapw<-pwRDA(nemao$x,nemao$y,nemabp[,1])


  }
image(log( nemao[[2]]+1))
nemapw$summ<-round(nemapw$summ,3)
sim1pw$summ<-round(sim1pw$summ,3)
sim2pw$summ<-round(sim2pw$summ,3)
sim3pw$summ<-round(sim3pw$summ,3)
sim4pw$summ<-round(sim4pw$summ,3)

nemapw$summ[,2][nemapw$summ[,2]<0.001]<-"<0.001"
sim1pw$summ[,2][sim1pw$summ[,2]<0.001]<-"<0.001"
sim2pw$summ[,2][sim2pw$summ[,2]<0.001]<-"<0.001"
sim3pw$summ[,2][sim3pw$summ[,2]<0.001]<-"<0.001"
sim4pw$summ[,2][sim4pw$summ[,2]<0.001]<-"<0.001"


{png("Fig1.png",res=300,width =12 ,height = 10,units = "in")

  lay<-layout(matrix(1:30,5,6, byrow=T), widths = c(.3,3,3,3,3,3), heights = c(.7,3,3,3,3))
  par(mar=c(0,0,0,0))
  plot.new()
  par(mar=c(0,1.4,0,0))
  plot.new()
  text(.5,.5, "Ordered array of \n species distribution",cex=1.2, font=2)
  plot.new()
  text(.5,.5, "full-RDA model",cex=1.2, font=2)
  plot.new()
  text(.5,.5, "SMW analyses",cex=1.2, font=2)
  plot.new()
  text(.5,.5, "pw-RDA model",cex=1.2, font=2)
  plot.new()
  text(.5,.5, "Summary statistics",cex=1.2, font=2)

  par(mar=c(5,.2,0,0))
  plot.new()
  text(.5,.5, "sim 1",srt=90, cex=1.5, font=2)

  par(mar=c(5,3,0,1), xpd=F)


  xplot<-1:dim(sim1o$y)[1]
  yplot<-seq(1,ncol(sim1o$y),length.out = dim(sim1o$y)[2])
  image(xplot,yplot,(as.matrix(sim1o$y)), las=1, axes=F, ylab="Bray-Curtis index", xlab="Ordered sites",
        col=topo.colors(200), mgp=c(1,0,0))
  abline(v=sim1bp$positions, col="red", lwd=3, lty=2)


  plot(sim1pw$rda.0,type="n",pch=16,las=1, tck=0,xlab="RDA I",ylab="RDA II",axes=T,tck=0)
  points(sim1pw$rda.0,display="species",pch=3,axis.bp=T,col="red")
  points(sim1pw$rda.0,display="sites",pch=16,axis.bp=T)
  text(sim1pw$rda.0,display="bp",pch=16,axis.bp=F,col="steelblue4",lwd=2)
  Dprofile(sim1pool,sim1bp$positions,xlab="site positions", ylab="Z-score",legend=F, tck=0,bty="n", bty="o")
  plot(sim1pw$rda.pw,type="n",pch=16,las=1,  xlab="RDA I",ylab=" RDAII", tck=0)
  points(sim1pw$rda.pw,display="species",pch=3,axis.bp=F,col="red")
  points(sim1pw$rda.pw,display="sites",pch=16,axis.bp=F)
  text(sim1pw$rda.pw,display="bp",pch=16,axis.bp=F,col="steelblue4",lwd=2)
  par(mar=c(0,0,0,0))
  plot.new()
  legend("center",ncol=3,horzi,legend=c("","Radj:full","Radj:pw","F","Statistic",sim1pw$summ[,1],
                                        "P.value",sim1pw$summ[,2]))


  par(mar=c(5,.2,0,0))
  plot.new()
  text(.5,.5, "sim 2",srt=90, cex=1.5, font=2)
  par(mar=c(5,3,0,1), xpd=F)
  xplot<-1:dim(sim2o$y)[1]
  yplot<-seq(1,ncol(sim2o$y),length.out = dim(sim2o$y)[2])
  image(xplot,yplot,(as.matrix(sim2o$y)), las=1, axes=F, ylab="Bray-Curtis index", xlab="Ordered sites",
        col=topo.colors(200), mgp=c(1,0,0))
  abline(v=c(sim2bp$positions), col="red", lwd=3, lty=2)
  plot(sim2pw$rda.0,type="n",pch=16,las=1, tck=0,xlab="RDA I",ylab="RDA II",axes=T,tck=0)
  points(sim2pw$rda.0,display="species",pch=3,axis.bp=T,col="red")
  points(sim2pw$rda.0,display="sites",pch=16,axis.bp=T)
  text(sim2pw$rda.0,display="bp",pch=16,axis.bp=F,col="steelblue4",lwd=2)
  Dprofile(sim2pool,sim2bp$positions,xlab="site positions", ylab="Z-score",legend=F, tck=0,bty="n", bty="o")


  plot(sim2pw$rda.pw,type="n",pch=16,las=1,  xlab="RDA I",ylab=" RDAII", tck=0)
  points(sim2pw$rda.pw,display="species",pch=3,axis.bp=F,col="red")
  points(sim2pw$rda.pw,display="sites",pch=16,axis.bp=F)
  text(sim2pw$rda.pw,display="bp",pch=16,axis.bp=F,col="steelblue4",lwd=2)
  par(mar=c(0,0,0,0))
  plot.new()
  legend("center",ncol=3,horzi,legend=c("","Radj:full","Radj:pw","F","Statistic",sim2pw$summ[,1],
                                        "P.value",sim2pw$summ[,2]))

  par(mar=c(5,.2,0,0))
  plot.new()
  text(.5,.5, "sim 3",srt=90, cex=1.5, font=2)
  par(mar=c(5,3,0,1), xpd=F)
  xplot<-1:dim(sim4o$y)[1]
  yplot<-seq(1,ncol(sim4o$y),length.out = dim(sim4o$y)[2])
  image(xplot,yplot,(as.matrix(sim4o$y)), las=1, axes=F, ylab="Bray-Curtis index", xlab="Ordered sites",
        col=topo.colors(200), mgp=c(1,0,0))
  abline(v=c(sim4bp$positions,49), col="red", lwd=3, lty=c(2))
  plot(sim4pw$rda.0,type="n",pch=16,las=1, tck=0,xlab="RDA I",ylab="RDA II",axes=T,tck=0)
  points(sim4pw$rda.0,display="species",pch=3,axis.bp=T,col="red")
  points(sim4pw$rda.0,display="sites",pch=16,axis.bp=T)
  text(sim4pw$rda.0,display="bp",pch=16,axis.bp=F,col="steelblue4",lwd=2)
  Dprofile(sim4pool,c(49,sim4bp$positions),xlab="site positions", ylab="Z-score",legend=F, tck=0,bty="n", bty="o")


   plot(sim4pw$rda.pw,type="n",pch=16,las=1,  xlab="RDA I",ylab=" RDAII", tck=0)
  points(sim4pw$rda.pw,display="species",pch=3,axis.bp=F,col="red")
  points(sim4pw$rda.pw,display="sites",pch=16,axis.bp=F)
  text(sim4pw$rda.pw,display="bp",pch=16,axis.bp=F,col="steelblue4",lwd=2)
  par(mar=c(0,0,0,0))
  plot.new()
  legend("center",ncol=3,horzi,legend=c("","Radj:full","Radj:pw","F","Statistic",sim4pw$summ[,1],
                                        "P.value",sim4pw$summ[,2]))
  par(mar=c(5,.2,0,0))
  plot.new()
  text(.5,.5, "sim 4",srt=90, cex=1.5, font=2)
  par(mar=c(5,3,0,1), xpd=F)
  xplot<-1:dim(sim3o$y)[1]
  yplot<-seq(1,ncol(sim3o$y),length.out = dim(sim3o$y)[2])
  image(xplot,yplot,(as.matrix(sim3o$y)), las=1, axes=F, ylab="Bray-Curtis index", xlab="Ordered sites",
        col=topo.colors(200), mgp=c(1,0,0))
  abline(v=sim3bp$positions, col="red", lwd=3, lty=2)
  abline(h=sim3bp$positions, col="red")
  plot(sim3pw$rda.0,type="n",pch=16,las=1, tck=0,xlab="RDA I",ylab="RDA II",axes=T,tck=0)
  points(sim3pw$rda.0,display="species",pch=3,axis.bp=T,col="red")
  points(sim3pw$rda.0,display="sites",pch=16,axis.bp=T)
  text(sim3pw$rda.0,display="bp",pch=16,axis.bp=F,col="steelblue4",lwd=2)
  Dprofile(sim3pool,sim3bp$positions,xlab="site positions", ylab="Z-score",legend=F, tck=0,bty="n", bty="o")
  plot(sim3pw$rda.pw,type="n",pch=16,las=1,  xlab="RDA I",ylab=" RDAII", tck=0)
  points(sim3pw$rda.pw,display="species",pch=3,axis.bp=F,col="red")
  points(sim3pw$rda.pw,display="sites",pch=16,axis.bp=F)
  text(sim3pw$rda.pw,display="bp",pch=16,axis.bp=F,col="steelblue4",lwd=2)
  par(mar=c(0,0,0,0))
  plot.new()
  legend("center",ncol=3,horzi,legend=c("","Radj:full","Radj:pw","F","Statistic",sim3pw$summ[,1],
                                        "P.value",sim3pw$summ[,2]))

  graphics.off()
  }

RsquareAdj(sim2pw$rda.pw)

summary(sim2pw$rda.0)[[7]]

summary(sim2pw$rda.pw)[[7]]


{png("Fig2.png",res=300,width =12 ,height = 3,units = "in")

  lay<-layout(matrix(1:12,2,6, byrow=T), widths = c(.3,3,3,3,3,3), heights = c(.7,3))

  par(mar=c(0,0,0,0))
  plot.new()
  par(mar=c(0,1.4,0,0))
  plot.new()
  text(.5,.5, "Ordered array of \n species distribution",cex=1.2, font=2)
  plot.new()
  text(.5,.5, "full-RDA model",cex=1.2, font=2)
  plot.new()
  text(.5,.5, "SMW analyses",cex=1.2, font=2)
  plot.new()
  text(.5,.5, "pw-RDA model",cex=1.2, font=2)
  plot.new()
  text(.5,.5, "Summary statistics",cex=1.2, font=2)

  par(mar=c(5,.2,0,0))
  plot.new()
  text(.5,.5, "Nematodes",srt=90, cex=1.5, font=2)

  par(mar=c(5,3,0,1), xpd=F)
  image(log(nemao$y+1),las=1,col=topo.colors(1000), xlab="sites",ylab="species",axes=F, mgp=c(1,0,0))
  plot(nemapw$rda.0,type="n",pch=16,las=1, tck=0,xlab="RDA I",ylab="RDA II",axes=T,tck=0)
  points(nemapw$rda.0,display="species",pch=3,axis.bp=T,col="red")
  points(nemapw$rda.0,display="sites",pch=16,axis.bp=T)
  text(nemapw$rda.0,display="bp",pch=16,axis.bp=F,col="steelblue4",lwd=2)
  Dprofile(nemapool,nemabp$positions,xlab="site positions", ylab="Z-score",legend=F, tck=0,bty="n", bty="o")
  plot(nemapw$rda.pw,type="n",pch=16,las=1,  xlab="RDA I",ylab=" RDAII", tck=0)
  points(nemapw$rda.pw,display="species",pch=3,axis.bp=F,col="red")
  points(nemapw$rda.pw,display="sites",pch=16,axis.bp=F)
  text(nemapw$rda.pw,display="bp",pch=16,axis.bp=F,col="steelblue4",lwd=2)
  par(mar=c(0,0,0,0))
  plot.new()
  legend("center",ncol=3,horzi,legend=c("","Radj:full","Radj:pw","F","Statistic",nemapw$summ[,1],
                                        "P.value",
                                        nemapw$summ[,2]))

  graphics.off()
}
